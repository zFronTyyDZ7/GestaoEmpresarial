package br.com.godigital.godigital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GodigitalApplicationTests {

	@Test
	void contextLoads() {
	}

}
