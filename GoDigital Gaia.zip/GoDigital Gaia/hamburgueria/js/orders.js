document.addEventListener('DOMContentLoaded', () => {
    const addButton = document.querySelector('.add-order');
    const ordersTable = document.getElementById('ordersTable').getElementsByTagName('tbody')[0];

    // Função para carregar todos os pedidos existentes
    function loadOrders() {
        fetch('http://localhost:8080/api/orders')
            .then(response => response.json())
            .then(data => {
                data.forEach(order => addRowToTable(order));
            })
            .catch(error => console.error('Erro ao carregar pedidos:', error));
    }

    addButton.addEventListener('click', () => {
        const newOrder = {
            customer: prompt('Digite o nome do cliente:'),
            status: prompt('Digite o status:'),
            total: parseFloat(prompt('Digite o valor total:'))
        };

        fetch('http://localhost:8080/api/orders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(newOrder)
        })
        .then(response => response.json())
        .then(data => {
            console.log('Pedido adicionado:', data);
            addRowToTable(data);
        })
        .catch(error => console.error('Erro ao adicionar pedido:', error));
    });

    function addRowToTable(order) {
        const row = ordersTable.insertRow();
        row.innerHTML = `
            <td>${order.id}</td>
            <td>${order.customer}</td>
            <td>${order.status}</td>
            <td>${order.total}</td>
            <td>
                <button class="edit-order" data-id="${order.id}">Editar</button>
                <button class="delete-order" data-id="${order.id}">Excluir</button>
            </td>
        `;

        row.querySelector('.edit-order').addEventListener('click', () => editOrder(order.id));
        row.querySelector('.delete-order').addEventListener('click', () => deleteOrder(order.id, row));
    }

    function editOrder(id) {
        const customer = prompt('Digite o novo nome do cliente:');
        const status = prompt('Digite o novo status:');
        const total = parseFloat(prompt('Digite o novo valor total:'));

        fetch(`http://localhost:8080/api/orders/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id, customer, status, total })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Pedido atualizado:', data);
            updateRowInTable(data);
        })
        .catch(error => console.error('Erro ao atualizar pedido:', error));
    }

    function deleteOrder(id, row) {
        fetch(`http://localhost:8080/api/orders/${id}`, {
            method: 'DELETE'
        })
        .then(() => {
            console.log('Pedido excluído');
            row.remove();
        })
        .catch(error => console.error('Erro ao excluir pedido:', error));
    }

    function updateRowInTable(order) {
        const rows = ordersTable.rows;
        for (let i = 0; i < rows.length; i++) {
            if (rows[i].cells[0].innerText == order.id) {
                rows[i].cells[1].innerText = order.customer;
                rows[i].cells[2].innerText = order.status;
                rows[i].cells[3].innerText = order.total;
                break;
            }
        }
    }

    // Carregar os pedidos ao iniciar
    loadOrders();
});
