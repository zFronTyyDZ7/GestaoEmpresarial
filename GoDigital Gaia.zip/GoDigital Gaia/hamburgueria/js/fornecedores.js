document.addEventListener('DOMContentLoaded', () => {
    const addButton = document.querySelector('.add-supplier');
    const suppliersTable = document.getElementById('suppliersTable').getElementsByTagName('tbody')[0];

    function loadSuppliers() {
        fetch('http://localhost:8080/api/suppliers')
            .then(response => response.json())
            .then(data => {
                data.forEach(supplier => addRowToTable(supplier));
            })
            .catch(error => console.error('Erro ao carregar fornecedores:', error));
    }

    addButton.addEventListener('click', () => {
        const newSupplier = {
            name: prompt('Digite o nome do fornecedor:'),
            phone: prompt('Digite o telefone:'),
            address: prompt('Digite o endereço:')
        };

        fetch('http://localhost:8080/api/suppliers', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(newSupplier)
        })
        .then(response => response.json())
        .then(data => {
            console.log('Fornecedor adicionado:', data);
            addRowToTable(data);
        })
        .catch(error => console.error('Erro ao adicionar fornecedor:', error));
    });

    function addRowToTable(supplier) {
        const row = suppliersTable.insertRow();
        row.innerHTML = `
            <td>${supplier.id}</td>
            <td>${supplier.name}</td>
            <td>${supplier.phone}</td>
            <td>${supplier.address}</td>
            <td>
                <button class="edit-supplier" data-id="${supplier.id}">Editar</button>
                <button class="delete-supplier" data-id="${supplier.id}">Excluir</button>
            </td>
        `;

        row.querySelector('.edit-supplier').addEventListener('click', () => editSupplier(supplier.id));
        row.querySelector('.delete-supplier').addEventListener('click', () => deleteSupplier(supplier.id, row));
    }

    function editSupplier(id) {
        const name = prompt('Digite o novo nome do fornecedor:');
        const phone = prompt('Digite o novo telefone:');
        const address = prompt('Digite o novo endereço:');

        fetch(`http://localhost:8080/api/suppliers/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id, name, phone, address })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Fornecedor atualizado:', data);
            updateRowInTable(data);
        })
        .catch(error => console.error('Erro ao atualizar fornecedor:', error));
    }

    function deleteSupplier(id, row) {
        fetch(`http://localhost:8080/api/suppliers/${id}`, {
            method: 'DELETE'
        })
        .then(() => {
            console.log('Fornecedor excluído');
            row.remove();
        })
        .catch(error => console.error('Erro ao excluir fornecedor:', error));
    }

    function updateRowInTable(supplier) {
        const rows = suppliersTable.rows;
        for (let i = 0; i < rows.length; i++) {
            if (rows[i].cells[0].innerText == supplier.id) {
                rows[i].cells[1].innerText = supplier.name;
                rows[i].cells[2].innerText = supplier.phone;
                rows[i].cells[3].innerText = supplier.address;
                break;
            }
        }
    }

    loadSuppliers();
});
