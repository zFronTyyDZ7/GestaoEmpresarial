document.addEventListener('DOMContentLoaded', () => {
    const addButton = document.querySelector('.add-item');
    const inventoryTable = document.getElementById('inventoryTable').getElementsByTagName('tbody')[0];

    // Função para carregar todos os itens existentes no estoque
    function loadInventory() {
        fetch('http://localhost:8080/api/inventory')
            .then(response => response.json())
            .then(data => {
                data.forEach(item => addRowToTable(item));
            })
            .catch(error => console.error('Erro ao carregar estoque:', error));
    }

    addButton.addEventListener('click', () => {
        const newItem = {
            produto: prompt('Digite o nome do produto:'),
            quantidade: parseInt(prompt('Digite a quantidade:'), 10),
            preco: parseFloat(prompt('Digite o preço:'))
        };

        fetch('http://localhost:8080/api/inventory', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(newItem)
        })
        .then(response => response.json())
        .then(data => {
            console.log('Item adicionado:', data);
            addRowToTable(data);
        })
        .catch(error => console.error('Erro ao adicionar item:', error));
    });

    function addRowToTable(item) {
        const row = inventoryTable.insertRow();
        row.innerHTML = `
            <td>${item.id}</td>
            <td>${item.produto}</td>
            <td>${item.quantidade}</td>
            <td>${item.preco}</td>
            <td>
                <button class="edit-item" data-id="${item.id}">Editar</button>
                <button class="delete-item" data-id="${item.id}">Excluir</button>
            </td>
        `;

        row.querySelector('.edit-item').addEventListener('click', () => editItem(item.id));
        row.querySelector('.delete-item').addEventListener('click', () => deleteItem(item.id, row));
    }

    function editItem(id) {
        const produto = prompt('Digite o novo nome do produto:');
        const quantidade = parseInt(prompt('Digite a nova quantidade:'), 10);
        const preco = parseFloat(prompt('Digite o novo preço:'));

        fetch(`http://localhost:8080/api/inventory/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id, produto, quantidade, preco })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Item atualizado:', data);
            updateRowInTable(data);
        })
        .catch(error => console.error('Erro ao atualizar item:', error));
    }

    function deleteItem(id, row) {
        fetch(`http://localhost:8080/api/inventory/${id}`, {
            method: 'DELETE'
        })
        .then(() => {
            console.log('Item excluído');
            row.remove();
        })
        .catch(error => console.error('Erro ao excluir item:', error));
    }

    function updateRowInTable(item) {
        const rows = inventoryTable.rows;
        for (let i = 0; i < rows.length; i++) {
            if (rows[i].cells[0].innerText == item.id) {
                rows[i].cells[1].innerText = item.produto;
                rows[i].cells[2].innerText = item.quantidade;
                rows[i].cells[3].innerText = item.preco;
                break;
            }
        }
    }

    // Carregar o estoque ao iniciar
    loadInventory();
});
