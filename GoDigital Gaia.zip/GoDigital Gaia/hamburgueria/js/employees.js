document.addEventListener('DOMContentLoaded', () => {
    const addButton = document.querySelector('.add-employee');
    const employeesTable = document.getElementById('employeesTable').getElementsByTagName('tbody')[0];

    // Função para carregar todos os funcionários existentes
    function loadEmployees() {
        fetch('http://localhost:8080/api/employees')
            .then(response => response.json())
            .then(data => {
                data.forEach(employee => addRowToTable(employee));
            })
            .catch(error => console.error('Erro ao carregar funcionários:', error));
    }

    addButton.addEventListener('click', () => {
        const newEmployee = {
            name: prompt('Digite o nome do funcionário:'),
            position: prompt('Digite o cargo:'),
            schedule: prompt('Digite o horário:')
        };

        fetch('http://localhost:8080/api/employees', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(newEmployee)
        })
        .then(response => response.json())
        .then(data => {
            console.log('Funcionário adicionado:', data);
            addRowToTable(data);
        })
        .catch(error => console.error('Erro ao adicionar funcionário:', error));
    });

    function addRowToTable(employee) {
        const row = employeesTable.insertRow();
        row.innerHTML = `
            <td>${employee.id}</td>
            <td>${employee.name}</td>
            <td>${employee.position}</td>
            <td>${employee.schedule}</td>
            <td>
                <button class="edit-employee" data-id="${employee.id}">Editar</button>
                <button class="delete-employee" data-id="${employee.id}">Excluir</button>
            </td>
        `;

        row.querySelector('.edit-employee').addEventListener('click', () => editEmployee(employee.id));
        row.querySelector('.delete-employee').addEventListener('click', () => deleteEmployee(employee.id, row));
    }

    function editEmployee(id) {
        const name = prompt('Digite o novo nome do funcionário:');
        const position = prompt('Digite o novo cargo:');
        const schedule = prompt('Digite o novo horário:');

        fetch(`http://localhost:8080/api/employees/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id, name, position, schedule })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Funcionário atualizado:', data);
            updateRowInTable(data);
        })
        .catch(error => console.error('Erro ao atualizar funcionário:', error));
    }

    function deleteEmployee(id, row) {
        fetch(`http://localhost:8080/api/employees/${id}`, {
            method: 'DELETE'
        })
        .then(() => {
            console.log('Funcionário excluído');
            row.remove();
        })
        .catch(error => console.error('Erro ao excluir funcionário:', error));
    }

    function updateRowInTable(employee) {
        const rows = employeesTable.rows;
        for (let i = 0; i < rows.length; i++) {
            if (rows[i].cells[0].innerText == employee.id) {
                rows[i].cells[1].innerText = employee.name;
                rows[i].cells[2].innerText = employee.position;
                rows[i].cells[3].innerText = employee.schedule;
                break;
            }
        }
    }

    // Carregar os funcionários ao iniciar
    loadEmployees();
});
